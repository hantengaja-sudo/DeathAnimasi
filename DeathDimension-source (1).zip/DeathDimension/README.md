# DeathDimension

Saat pemain mati: title "KAMU MATI", ring partikel biru + layar menggelap, lalu pemain
ditarik ke **Realm of the Dead** dengan countdown, dan bangkit lagi di titik respawn.

## Build
Butuh JDK 21 dan Maven:

    mvn clean package

Hasil: `target/DeathDimension.jar` -> taruh di `plugins/` (Paper 1.21.x).

## Setup
1. Jalankan server sekali. World void `realm_of_the_dead` dibuat otomatis
   (atau buat sendiri lewat Multiverse, lalu `create-world-if-missing: false`).
2. Berdiri di titik realm yang kamu mau -> `/dd setspawn`
3. Isi `disabled-worlds` di config (contoh: world `pvp` untuk duel).
4. Ubah teks/warna/font di `lang.yml`, durasi di `config.yml`.

## Command & permission
- `/dd reload`, `/dd setspawn`, `/dd release <pemain>`, `/dd send <pemain>` -> `deathdimension.admin`
- `deathdimension.bypass` -> tidak kena hukuman (default: false, OP pun tidak otomatis bypass)
