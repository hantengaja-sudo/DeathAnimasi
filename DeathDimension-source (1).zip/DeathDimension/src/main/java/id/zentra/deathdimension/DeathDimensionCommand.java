package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class DeathDimensionCommand implements CommandExecutor, TabCompleter {

    private final DeathDimension plugin;
    private final RealmManager realm;

    public DeathDimensionCommand(DeathDimension plugin, RealmManager realm) {
        this.plugin = plugin;
        this.realm = realm;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathdimension.admin")) {
            sender.sendMessage(plugin.lang().get("admin-no-perm"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(plugin.lang().get("admin-help"));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                plugin.lang().reload();
                realm.ensureWorld();
                sender.sendMessage(plugin.lang().get("admin-reloaded"));
            }
            case "setspawn" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Hanya untuk pemain.");
                    return true;
                }
                Location l = p.getLocation();
                plugin.getConfig().set("dimension-location.world", l.getWorld().getName());
                plugin.getConfig().set("dimension-location.x", l.getX());
                plugin.getConfig().set("dimension-location.y", l.getY());
                plugin.getConfig().set("dimension-location.z", l.getZ());
                plugin.getConfig().set("dimension-location.yaw", (double) l.getYaw());
                plugin.getConfig().set("dimension-location.pitch", (double) l.getPitch());
                plugin.saveConfig();
                sender.sendMessage(plugin.lang().get("admin-spawn-set"));
            }
            case "release" -> {
                Player t = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (t == null) {
                    sender.sendMessage(plugin.lang().get("admin-player-offline"));
                    return true;
                }
                realm.release(t);
                sender.sendMessage(plugin.lang().get("admin-released", "player", t.getName()));
            }
            case "send" -> {
                Player t = args.length > 1 ? Bukkit.getPlayerExact(args[1]) : null;
                if (t == null) {
                    sender.sendMessage(plugin.lang().get("admin-player-offline"));
                    return true;
                }
                if (realm.realmLocation() == null) {
                    sender.sendMessage(plugin.lang().get("admin-no-realm"));
                    return true;
                }
                realm.enterRealm(t, realm.realmMillis());
                sender.sendMessage(plugin.lang().get("admin-sent", "player", t.getName()));
            }
            default -> sender.sendMessage(plugin.lang().get("admin-help"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("deathdimension.admin")) {
            return out;
        }
        if (args.length == 1) {
            for (String s : List.of("reload", "setspawn", "release", "send")) {
                if (s.startsWith(args[0].toLowerCase())) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("release") || args[0].equalsIgnoreCase("send"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }
}
