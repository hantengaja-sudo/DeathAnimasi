package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;

public final class DeathListener implements Listener {

    private final DeathDimension plugin;
    private final RealmManager realm;

    public DeathListener(DeathDimension plugin, RealmManager realm) {
        this.plugin = plugin;
        this.realm = realm;
    }

    /** Damage mematikan dibatalkan, diganti animasi "ditarik ke kehampaan". */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) {
            return;
        }
        if (realm.isBusy(p)) {
            e.setCancelled(true);
            return;
        }
        if (!realm.shouldHandle(p)) {
            return;
        }
        EntityDamageEvent.DamageCause cause = e.getCause();
        if (cause == EntityDamageEvent.DamageCause.VOID
                || cause == EntityDamageEvent.DamageCause.KILL
                || cause == EntityDamageEvent.DamageCause.WORLD_BORDER) {
            return; // tetap mati biasa, tapi tetap masuk realm lewat onDeath
        }
        if (p.getHealth() - e.getFinalDamage() > 0) {
            return;
        }
        if (hasTotem(p)) {
            return; // biarkan totem bekerja
        }
        e.setCancelled(true);
        realm.startPull(p);
    }

    private boolean hasTotem(Player p) {
        ItemStack main = p.getInventory().getItemInMainHand();
        ItemStack off = p.getInventory().getItemInOffHand();
        return main.getType() == Material.TOTEM_OF_UNDYING || off.getType() == Material.TOTEM_OF_UNDYING;
    }

    /** Semua kematian (animasi selesai, /kill, void, dll) diarahkan ke realm. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (realm.isInRealm(p)) {
            // mati di dalam realm (misal /kill): tidak ada drop, ulangi hukuman
            e.setKeepInventory(true);
            e.setKeepLevel(true);
            e.getDrops().clear();
            e.setDroppedExp(0);
            e.deathMessage(null);
            realm.markToRealm(p);
        } else if (realm.shouldHandle(p) || realm.isMarked(p)) {
            realm.markToRealm(p);
        } else {
            return;
        }
        // lewati layar kematian: respawn otomatis 1 tick kemudian
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline() && p.isDead()) {
                p.spigot().respawn();
            }
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!realm.consumeToRealm(p)) {
            return;
        }
        Location loc = realm.realmLocation();
        if (loc == null) {
            return;
        }
        e.setRespawnLocation(loc);
        Bukkit.getScheduler().runTask(plugin, () -> realm.enterRealm(p, realm.realmMillis()));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> realm.recover(p), 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        realm.handleQuit(e.getPlayer());
    }
}
