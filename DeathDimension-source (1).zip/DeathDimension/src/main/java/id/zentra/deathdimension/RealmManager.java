package id.zentra.deathdimension;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Inti plugin. Hanya SATU task global (tiap tick) untuk semua pemain, dan task itu
 * langsung selesai kalau tidak ada yang sedang dihukum, jadi tidak membebani server.
 *
 * Alur: damage mematikan dibatalkan -> animasi "ditarik" -> mati asli (item/XP
 * tetap diproses server & plugin lain) -> respawn instan ke realm -> countdown
 * -> bebas ke titik respawn.
 */
public final class RealmManager {

    private static final Particle.DustOptions DUST_A = new Particle.DustOptions(Color.fromRGB(0, 230, 255), 1.3f);
    private static final Particle.DustOptions DUST_B = new Particle.DustOptions(Color.fromRGB(150, 255, 255), 0.9f);

    private static final class Realm {
        long until;
        int shown = -1;

        Realm(long until) {
            this.until = until;
        }
    }

    private final DeathDimension plugin;
    private final Map<UUID, Integer> pulling = new HashMap<>();
    private final Map<UUID, Realm> inRealm = new HashMap<>();
    private final Set<UUID> toRealm = new HashSet<>();

    private final NamespacedKey keyUntil;
    private final NamespacedKey keyGm;
    private final BukkitTask task;
    private int counter;

    public RealmManager(DeathDimension plugin) {
        this.plugin = plugin;
        this.keyUntil = new NamespacedKey(plugin, "until");
        this.keyGm = new NamespacedKey(plugin, "gm");
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void shutdown() {
        task.cancel();
        for (UUID id : pulling.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.setInvulnerable(false);
                p.removePotionEffect(PotionEffectType.DARKNESS);
            }
        }
        pulling.clear();
        // pemain di realm tetap aman: data PDC dipakai untuk memulihkan saat server hidup lagi
        inRealm.clear();
    }

    // ------------------------------------------------------------------
    //  Status
    // ------------------------------------------------------------------

    public boolean isPulling(Player p) {
        return pulling.containsKey(p.getUniqueId());
    }

    public boolean isInRealm(Player p) {
        return inRealm.containsKey(p.getUniqueId());
    }

    public boolean isBusy(Player p) {
        return isPulling(p) || isInRealm(p);
    }

    public @Nullable Location realmLocation() {
        return plugin.dimensionLocation();
    }

    /** Apakah kematian pemain ini harus diproses plugin? */
    public boolean shouldHandle(Player p) {
        if (p.hasPermission("deathdimension.bypass")) {
            return false;
        }
        Location loc = realmLocation();
        if (loc == null) {
            return false;
        }
        if (p.getWorld().equals(loc.getWorld())) {
            return false;
        }
        return !plugin.getConfig().getStringList("disabled-worlds").contains(p.getWorld().getName());
    }

    public void markToRealm(Player p) {
        toRealm.add(p.getUniqueId());
    }

    public boolean isMarked(Player p) {
        return toRealm.contains(p.getUniqueId());
    }

    public boolean consumeToRealm(Player p) {
        return toRealm.remove(p.getUniqueId());
    }

    public long realmMillis() {
        return plugin.getConfig().getLong("timing.realm-seconds", 10L) * 1000L;
    }

    // ------------------------------------------------------------------
    //  World realm
    // ------------------------------------------------------------------

    public void ensureWorld() {
        String name = plugin.getConfig().getString("dimension-location.world", "realm_of_the_dead");
        World world = Bukkit.getWorld(name);
        if (world == null && plugin.getConfig().getBoolean("create-world-if-missing", true)) {
            WorldCreator wc = new WorldCreator(name);
            wc.generator(new VoidGenerator());
            wc.generateStructures(false);
            world = wc.createWorld();
            if (world != null) {
                plugin.getLogger().info("World realm '" + name + "' dibuat (void).");
            }
        }
        if (world == null) {
            plugin.getLogger().warning("World realm '" + name + "' tidak ada. Hukuman mati dinonaktifkan sampai world dibuat.");
            return;
        }
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setTime(18000L);
        world.setStorm(false);
        buildPlatform();
    }

    private void buildPlatform() {
        if (!plugin.getConfig().getBoolean("platform.enabled", true)) {
            return;
        }
        Location loc = realmLocation();
        if (loc == null) {
            return;
        }
        Material mat = Material.matchMaterial(plugin.getConfig().getString("platform.material", "BLACK_CONCRETE"));
        if (mat == null || !mat.isBlock()) {
            mat = Material.BLACK_CONCRETE;
        }
        int r = Math.max(1, plugin.getConfig().getInt("platform.radius", 3));
        World w = loc.getWorld();
        int cx = loc.getBlockX();
        int cy = loc.getBlockY() - 1;
        int cz = loc.getBlockZ();
        if (!w.getBlockAt(cx, cy, cz).getType().isAir()) {
            return;
        }
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                w.getBlockAt(cx + x, cy, cz + z).setType(mat, false);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Fase 1: animasi "ditarik" di tempat mati
    // ------------------------------------------------------------------

    public void startPull(Player p) {
        pulling.put(p.getUniqueId(), 0);
        int ticks = plugin.getConfig().getInt("timing.pull-ticks", 60);
        p.setInvulnerable(true);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setRemainingAir(p.getMaximumAir());
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, ticks + 20, 0, false, false, false));
        p.showTitle(Title.title(
                plugin.lang().get("death-title"),
                plugin.lang().get("death-subtitle"),
                Title.Times.times(Duration.ofMillis(250), Duration.ofMillis(ticks * 50L), Duration.ofMillis(300))));
        playSound(p, "sounds.pull-start");
    }

    private void tick() {
        if (!pulling.isEmpty()) {
            pullTick();
        }
        if (++counter >= 5) {
            counter = 0;
            if (!inRealm.isEmpty()) {
                realmTick();
            }
        }
    }

    private void pullTick() {
        int total = plugin.getConfig().getInt("timing.pull-ticks", 60);
        Iterator<Map.Entry<UUID, Integer>> it = pulling.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null || !p.isOnline() || p.isDead()) {
                it.remove();
                continue;
            }
            int t = e.getValue();
            e.setValue(t + 1);
            p.setFireTicks(0);
            p.setFallDistance(0f);
            effects(p, t, total);
            if (t + 1 >= total) {
                it.remove();
                finishPull(p);
            }
        }
    }

    /** Ring biru di tanah + 3 lengan spiral yang naik, mengecil seiring waktu. */
    private void effects(Player p, int t, int total) {
        Location base = p.getLocation();
        World w = base.getWorld();
        double prog = Math.min(1.0, t / (double) Math.max(1, total));

        double radius = 1.5 - 1.0 * prog;
        int ring = 14;
        for (int i = 0; i < ring; i++) {
            double a = (Math.PI * 2 / ring) * i + t * 0.22;
            w.spawnParticle(Particle.DUST,
                    base.getX() + Math.cos(a) * radius, base.getY() + 0.08, base.getZ() + Math.sin(a) * radius,
                    1, 0, 0, 0, 0, i % 2 == 0 ? DUST_A : DUST_B);
        }
        for (int k = 0; k < 3; k++) {
            double a = t * 0.38 + k * (Math.PI * 2 / 3);
            double h = ((t * 0.07) + k * 0.7) % 2.2;
            double rr = 0.95 * (1.0 - h / 2.6);
            w.spawnParticle(Particle.END_ROD,
                    base.getX() + Math.cos(a) * rr, base.getY() + h, base.getZ() + Math.sin(a) * rr,
                    1, 0, 0, 0, 0);
        }
        if (t % 6 == 0) {
            w.spawnParticle(Particle.SOUL_FIRE_FLAME, base.getX(), base.getY() + 1.0, base.getZ(), 3, 0.3, 0.5, 0.3, 0.01);
        }
        if (t + 1 >= total - 1) {
            w.spawnParticle(Particle.REVERSE_PORTAL, base.getX(), base.getY() + 1.0, base.getZ(), 40, 0.3, 0.6, 0.3, 0.5);
            w.spawnParticle(Particle.TOTEM_OF_UNDYING, base.getX(), base.getY() + 1.0, base.getZ(), 25, 0.4, 0.6, 0.4, 0.2);
        }
    }

    /** Mati asli (item/XP/stat/plugin lain tetap jalan), lalu DeathListener memicu respawn ke realm. */
    private void finishPull(Player p) {
        p.setInvulnerable(false);
        p.removePotionEffect(PotionEffectType.DARKNESS);
        playSound(p, "sounds.pull-end");
        toRealm.add(p.getUniqueId());
        p.setHealth(0.0);
    }

    // ------------------------------------------------------------------
    //  Fase 2: di realm
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    public void enterRealm(Player p, long millis) {
        Location loc = realmLocation();
        if (loc == null || !p.isOnline()) {
            return;
        }
        UUID id = p.getUniqueId();
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (!pdc.has(keyGm, PersistentDataType.STRING)) {
            pdc.set(keyGm, PersistentDataType.STRING, p.getGameMode().name());
        }
        long until = System.currentTimeMillis() + millis;
        pdc.set(keyUntil, PersistentDataType.LONG, until);
        inRealm.put(id, new Realm(until));
        pulling.remove(id);

        if (!p.getWorld().equals(loc.getWorld()) || p.getLocation().distanceSquared(loc) > 4.0) {
            p.teleport(loc);
        }
        p.setGameMode(GameMode.ADVENTURE);
        p.setInvulnerable(true);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        for (PotionEffect eff : p.getActivePotionEffects()) {
            p.removePotionEffect(eff.getType());
        }
        realmTick(); // tampilkan title langsung, tanpa menunggu siklus berikutnya
    }

    private void realmTick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Realm>> it = inRealm.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Realm> e = it.next();
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null || !p.isOnline()) {
                it.remove();
                continue;
            }
            Realm r = e.getValue();
            long left = r.until - now;
            if (left <= 0) {
                it.remove();
                finishRelease(p);
                continue;
            }
            int sec = (int) Math.ceil(left / 1000.0);
            if (sec == r.shown) {
                continue;
            }
            r.shown = sec;
            showRealm(p, sec);
            if (sec <= 3) {
                playSound(p, "sounds.realm-tick");
            }
        }
    }

    private void showRealm(Player p, int sec) {
        int total = (int) Math.max(1, plugin.getConfig().getLong("timing.realm-seconds", 10L));
        double ratio = sec / (double) total;
        String color = ratio > 0.5 ? "<green>" : (ratio > 0.25 ? "<yellow>" : "<red>");
        p.showTitle(Title.title(
                plugin.lang().get("realm-title"),
                plugin.lang().get("realm-subtitle", "time", String.valueOf(sec)),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1500), Duration.ZERO)));
        p.sendActionBar(plugin.lang().get("realm-actionbar", "time", String.valueOf(sec), "color", color));
    }

    // ------------------------------------------------------------------
    //  Fase 3: bebas
    // ------------------------------------------------------------------

    /** Bebaskan pemain sekarang juga (dipakai admin & pemulihan). */
    public void release(Player p) {
        inRealm.remove(p.getUniqueId());
        finishRelease(p);
    }

    @SuppressWarnings("deprecation")
    private void finishRelease(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        GameMode gm = GameMode.SURVIVAL;
        String stored = pdc.get(keyGm, PersistentDataType.STRING);
        if (stored != null) {
            try {
                gm = GameMode.valueOf(stored);
            } catch (IllegalArgumentException ignored) {
                // pakai SURVIVAL
            }
        }
        pdc.remove(keyGm);
        pdc.remove(keyUntil);

        p.setInvulnerable(false);
        p.setGameMode(gm);
        for (PotionEffect eff : p.getActivePotionEffects()) {
            p.removePotionEffect(eff.getType());
        }
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(10f);
        p.setFireTicks(0);
        p.setFallDistance(0f);

        Location dest = p.getRespawnLocation();
        if (dest == null) {
            dest = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        p.teleportAsync(dest).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) {
                return;
            }
            p.showTitle(Title.title(
                    plugin.lang().get("released-title"),
                    plugin.lang().get("released-subtitle"),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(2000), Duration.ofMillis(600))));
            p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 30, 0.4, 0.6, 0.4, 0.2);
            playSound(p, "sounds.release");
        }));
    }

    // ------------------------------------------------------------------
    //  Join / quit
    // ------------------------------------------------------------------

    /** Pulihkan pemain yang logout / server crash saat dihukum. */
    public void recover(Player p) {
        if (!p.isOnline() || isBusy(p)) {
            return;
        }
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        Long until = pdc.get(keyUntil, PersistentDataType.LONG);
        if (until != null) {
            long left = until - System.currentTimeMillis();
            if (left > 0 && realmLocation() != null) {
                enterRealm(p, left);
            } else {
                finishRelease(p);
            }
            return;
        }
        Location rl = realmLocation();
        if (rl != null && p.getWorld().equals(rl.getWorld())) {
            GameMode gm = p.getGameMode();
            if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
                finishRelease(p); // nyasar di realm tanpa hukuman aktif
            }
        }
    }

    public void handleQuit(Player p) {
        UUID id = p.getUniqueId();
        if (pulling.remove(id) != null) {
            // logout saat animasi ditarik = tetap mati (anti combat-log)
            PersistentDataContainer pdc = p.getPersistentDataContainer();
            pdc.set(keyGm, PersistentDataType.STRING, p.getGameMode().name());
            pdc.set(keyUntil, PersistentDataType.LONG, System.currentTimeMillis() + realmMillis());
            p.setInvulnerable(false);
            p.removePotionEffect(PotionEffectType.DARKNESS);
            p.setHealth(0.0);
            toRealm.remove(id);
        }
        inRealm.remove(id);
        toRealm.remove(id);
    }

    // ------------------------------------------------------------------

    private void playSound(Player p, String path) {
        String raw = plugin.getConfig().getString(path, "");
        if (raw == null || raw.isBlank()) {
            return;
        }
        String[] parts = raw.split(",");
        float vol = 1f;
        float pitch = 1f;
        try {
            if (parts.length > 1) {
                vol = Float.parseFloat(parts[1].trim());
            }
            if (parts.length > 2) {
                pitch = Float.parseFloat(parts[2].trim());
            }
        } catch (NumberFormatException ignored) {
            // pakai default
        }
        p.playSound(p.getLocation(), parts[0].trim(), SoundCategory.MASTER, vol, pitch);
    }
}
