package id.zentra.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;

public final class Lang {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final DeathDimension plugin;
    private FileConfiguration cfg;

    public Lang(DeathDimension plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File f = new File(plugin.getDataFolder(), "lang.yml");
        if (!f.exists()) {
            plugin.saveResource("lang.yml", false);
        }
        cfg = YamlConfiguration.loadConfiguration(f);
    }

    /** Ambil teks MiniMessage. Pasangan kv: nama, nilai, nama, nilai ... */
    public Component get(String key, String... kv) {
        String s = cfg.getString(key, "<red>lang tidak ada: " + key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return MM.deserialize(s);
    }
}
