package id.zentra.deathdimension;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.jetbrains.annotations.Nullable;

import java.util.Random;

/** Generator world kosong (void). Tidak menggenerate apa pun, jadi ringan. */
public final class VoidGenerator extends ChunkGenerator {

    @Override
    public @Nullable Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 0.5, 65.0, 0.5);
    }
}
