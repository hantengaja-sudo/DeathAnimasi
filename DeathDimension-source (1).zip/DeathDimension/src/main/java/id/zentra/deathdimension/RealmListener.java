package id.zentra.deathdimension;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.List;

/** Pembatasan saat animasi ditarik & saat di realm. Semua cek O(1), tanpa task. */
public final class RealmListener implements Listener {

    private final DeathDimension plugin;
    private final RealmManager realm;

    public RealmListener(DeathDimension plugin, RealmManager realm) {
        this.plugin = plugin;
        this.realm = realm;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) {
            return;
        }
        if (realm.isPulling(p)) {
            // beku di tempat (boleh menoleh, boleh jatuh)
            if (from.getX() != to.getX() || from.getZ() != to.getZ() || to.getY() > from.getY()) {
                Location n = from.clone();
                n.setYaw(to.getYaw());
                n.setPitch(to.getPitch());
                e.setTo(n);
            }
            return;
        }
        if (realm.isInRealm(p)) {
            Location center = realm.realmLocation();
            if (center == null || !center.getWorld().equals(to.getWorld())) {
                return;
            }
            double max = plugin.getConfig().getDouble("realm.max-radius", 40.0);
            double dx = to.getX() - center.getX();
            double dz = to.getZ() - center.getZ();
            boolean tooFar = dx * dx + dz * dz > max * max;
            boolean fell = to.getY() < center.getY() - 20.0;
            if (tooFar || fell) {
                Location back = center.clone();
                back.setYaw(to.getYaw());
                back.setPitch(to.getPitch());
                p.setFallDistance(0f);
                e.setTo(back);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!realm.isBusy(p) || p.hasPermission("deathdimension.admin")) {
            return;
        }
        String msg = e.getMessage().toLowerCase();
        String label = msg.startsWith("/") ? msg.substring(1) : msg;
        int space = label.indexOf(' ');
        if (space >= 0) {
            label = label.substring(0, space);
        }
        if (label.startsWith("minecraft:")) {
            label = label.substring(10);
        }
        List<String> allowed = plugin.getConfig().getStringList("realm.allowed-commands");
        if (allowed.contains(label)) {
            return;
        }
        e.setCancelled(true);
        p.sendMessage(plugin.lang().get("command-blocked"));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        // teleport dari plugin/command/pearl dibatalkan selama hukuman
        if (realm.isInRealm(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (realm.isBusy(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (realm.isBusy(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (realm.isBusy(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (realm.isBusy(e.getPlayer())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && realm.isBusy(p)) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && realm.isBusy(p)) {
            e.setCancelled(true);
        }
    }
}
