package id.zentra.deathdimension;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

public final class DeathDimension extends JavaPlugin {

    private Lang lang;
    private RealmManager realm;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        lang = new Lang(this);
        realm = new RealmManager(this);

        Bukkit.getPluginManager().registerEvents(new DeathListener(this, realm), this);
        Bukkit.getPluginManager().registerEvents(new RealmListener(this, realm), this);

        DeathDimensionCommand cmd = new DeathDimensionCommand(this, realm);
        getCommand("deathdimension").setExecutor(cmd);
        getCommand("deathdimension").setTabCompleter(cmd);

        // jalan setelah semua world (termasuk Multiverse) selesai dimuat
        Bukkit.getScheduler().runTask(this, () -> {
            realm.ensureWorld();
            for (Player p : Bukkit.getOnlinePlayers()) {
                realm.recover(p);
            }
        });
    }

    @Override
    public void onDisable() {
        if (realm != null) {
            realm.shutdown();
        }
    }

    @Override
    public @Nullable ChunkGenerator getDefaultWorldGenerator(String worldName, @Nullable String id) {
        return new VoidGenerator();
    }

    public Lang lang() {
        return lang;
    }

    public RealmManager realm() {
        return realm;
    }

    /** Lokasi realm dari config, atau null kalau world belum ada. */
    public @Nullable Location dimensionLocation() {
        String worldName = getConfig().getString("dimension-location.world", "realm_of_the_dead");
        if (worldName == null || worldName.isEmpty()) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(
                world,
                getConfig().getDouble("dimension-location.x", 0.5),
                getConfig().getDouble("dimension-location.y", 65.0),
                getConfig().getDouble("dimension-location.z", 0.5),
                (float) getConfig().getDouble("dimension-location.yaw", 0.0),
                (float) getConfig().getDouble("dimension-location.pitch", 0.0));
    }
}
